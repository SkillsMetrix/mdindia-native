import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { MD3LightTheme, PaperProvider } from 'react-native-paper';
import ContactsDemo2 from './screens/ContactsDemo2';
import CameraScreen from './screens/CameraScreen';
import ContactApp from './components/ContactApp';
import ContactApp2 from './components/ContactApp2';
import ContactApp3 from './components/ContactApp3';
import LocationScreen from './screens/LocationScreen';



export default function App() {
  return (
     <PaperProvider>
   <LocationScreen/>
   
     </PaperProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
