import api from "../api/api"

export const registerUser=async(userData) =>{
    const response= await api.post("/users",userData)
    return response.data
}



export const loginUser=async(username,password) =>{
    const response= await api.get("/users",{
        params:{
            username,password
        }
    })
    return response.data
}


export const loadUserss=async() =>{
    const response= await api.get("/users")
     
    
    return response.data
}


export const updateUserss=async(id,userData) =>{
    const response= await api.put(`/users/${id}`,userData)
    return response.data
}


export const deleteUserss=async(id) =>{
    const response= await api.delete(`/users/${id}`)
    return response.data
}
