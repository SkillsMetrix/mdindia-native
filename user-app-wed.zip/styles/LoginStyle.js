import { StyleSheet } from "react-native";

export const LoginStyles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: "center",
  },

  logo: {
    textAlign: "center",
    marginBottom: 20,
    fontWeight: "bold",
  },
  card: {
    padding: 10,
  },
  heading: {
    textAlign: "center",
    marginBottom: 20,
  },
  input: {
    marginBottom: 15,
  },
});
