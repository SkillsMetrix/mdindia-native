import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

const DashboardScreen = ({ navigation, route }) => {
  const user = route.params?.user;

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Welcome {user?.username}</Text>

      <TouchableOpacity onPress={() => navigation.navigate("UserDetails")}>
        <Text style={styles.link}>User Management</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate("Register")}>
        <Text style={styles.link}>Register User</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate("Login")}>
        <Text style={styles.link}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};

export default DashboardScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },

  heading: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 30,
  },

  link: {
    color: "blue",
    fontSize: 18,
    marginBottom: 15,
    textDecorationLine: "underline",
  },
});
