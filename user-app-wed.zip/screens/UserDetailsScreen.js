import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  Alert,
  StyleSheet,
} from "react-native";

import {
  loadUserss,
  updateUserss,
  deleteUserss,
} from "../services/authService";

const UserDetailsScreen = () => {
  const [users, setUsers] = useState([]);
  const [editingId, setEditingId] = useState(null);

  const [editData, setEditData] = useState({
    username: "",
    email: "",
  });

  const loadUsers = async () => {
    try {
      const data = await loadUserss();
      setUsers(data);
    } catch (error) {
      console.log(error);
      Alert.alert("Error", "Unable to load users");
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const startEdit = (user) => {
    setEditingId(user.id);

    setEditData({
      username: user.username,
      email: user.email,
    });
  };

  const saveUser = async (user) => {
    try {
      await updateUserss(user.id, {
        ...user,
        ...editData,
      });

      Alert.alert(
        "Success",
        "User Updated Successfully"
      );

      setEditingId(null);

      loadUsers();
    } catch (error) {
      console.log(error);

      Alert.alert(
        "Error",
        "Update Failed"
      );
    }
  };

/*   const removeUser = (id) => {
    Alert.alert(
      "Delete User",
      "Are you sure?",
      [
        {
          text: "Cancel",
          style: "cancel",
        },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              await deleteUserss(id);

              Alert.alert(
                "Success",
                "User Deleted"
              );

              loadUsers();
            } catch (error) {
              console.log(error);

              Alert.alert(
                "Error",
                "Delete Failed"
              );
            }
          },
        },
      ]
    );
  }; */
const removeUser = async (id) => {

  const confirmed = window.confirm(
    "Are you sure you want to delete this user?"
  );

  if (!confirmed) {
    return;
  }

  try {

    await deleteUserss(id);

    alert("User Deleted");

    loadUsers();

  } catch (error) {

    alert("Delete Failed");
  }
};
  const renderUser = ({ item }) => (
    <View style={styles.card}>
      {editingId === item.id ? (
        <>
          <TextInput
            style={styles.input}
            placeholder="Username"
            value={editData.username}
            onChangeText={(value) =>
              setEditData({
                ...editData,
                username: value,
              })
            }
          />

          <TextInput
            style={styles.input}
            placeholder="Email"
            value={editData.email}
            onChangeText={(value) =>
              setEditData({
                ...editData,
                email: value,
              })
            }
          />

          <View style={styles.buttonRow}>
            <TouchableOpacity
              style={styles.saveButton}
              onPress={() => saveUser(item)}
            >
              <Text style={styles.buttonText}>
                Save
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.cancelButton}
              onPress={() =>
                setEditingId(null)
              }
            >
              <Text style={styles.buttonText}>
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <>
          <Text style={styles.name}>
            {item.username}
          </Text>

          <Text style={styles.text}>
            {item.email}
          </Text>

          <Text style={styles.text}>
            User ID: {item.id}
          </Text>

          <View style={styles.buttonRow}>
            <TouchableOpacity
              style={styles.editButton}
              onPress={() =>
                startEdit(item)
              }
            >
              <Text style={styles.buttonText}>
                Edit
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.deleteButton}
              onPress={() =>
                removeUser(item.id)
              }
            >
              <Text style={styles.buttonText}>
                Delete
              </Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>
        User Management
      </Text>

      <FlatList
        data={users}
        keyExtractor={(item) =>
          item.id.toString()
        }
        renderItem={renderUser}
        onRefresh={loadUsers}
        refreshing={false}
      />
    </View>
  );
};

export default UserDetailsScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
  },

  heading: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 15,
  },

  card: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    backgroundColor: "#fff",
  },

  name: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 5,
  },

  text: {
    marginBottom: 5,
  },

  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    padding: 10,
    marginBottom: 10,
  },

  buttonRow: {
    flexDirection: "row",
    marginTop: 10,
  },

  editButton: {
    backgroundColor: "#4CAF50",
    padding: 10,
    borderRadius: 5,
    marginRight: 10,
  },

  deleteButton: {
    backgroundColor: "#f44336",
    padding: 10,
    borderRadius: 5,
  },

  saveButton: {
    backgroundColor: "#2196F3",
    padding: 10,
    borderRadius: 5,
    marginRight: 10,
  },

  cancelButton: {
    backgroundColor: "#9E9E9E",
    padding: 10,
    borderRadius: 5,
  },

  buttonText: {
    color: "#fff",
    fontWeight: "bold",
  },
});