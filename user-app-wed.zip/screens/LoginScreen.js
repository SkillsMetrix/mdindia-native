import { Alert, StyleSheet, View } from "react-native";
import {
  Text,
  TextInput,
  Button,
  Card,
  ActivityIndicator,
} from "react-native-paper";
import React, { useState } from "react";

import { validateLogin } from "../utils/validation";
import { LoginStyles } from "../styles/LoginStyle";
import { loginUser, registerUser } from "../services/authService";

const LoginScreen = ({ navigation }) => {
  const [formData, setFormData] = useState({
    username: "",
  });
  const [secureText,setSecureText]= useState(true)
  const [loading,setLoading]= useState(false)
  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleRegister = async () => {
    const error = validateLogin(formData);
    if (error) {
      alert("Validation Error", error);
      return;
    }
    try {
      const user = await loginUser(formData.username, formData.password);
      if (user.length === 0) {
        alert("Login failed");
        return;
      }
      alert("Login Success");
      navigation.navigate("Dashboard", {
        user: user[0],
      });
    } catch (error) {
      console.log(error);
      alert("unable to login");
    }
  };

  return (
    <View style={LoginStyles.container}>
      <Text variant="headlineMedium" style={LoginStyles.logo}>Employee Portal</Text>

      <Card style={LoginStyles.card}>
        <Card.Content>
          <Text variant="titleLarge" style={LoginStyles.heading}>Login</Text>

        <TextInput
        label="username"
        mode="outlined"
        value={formData.username}
        onChangeText={(value) => handleChange("username", value)}
        style={LoginStyles.input}
      />
      <TextInput
        label="password"
        mode="outlined"
        secureTextEntry={secureText}
        value={formData.password}
        onChangeText={(value) => handleChange("password", value)}
        right={<TextInput.Icon icon={
          secureText ? "eye" : "eye-off"
        } onPress={() => setSecureText(!secureText

        )
      }
      />
    }
        style={LoginStyles.input}
      />
      {loading ? (
        <ActivityIndicator/>
      ):(
        <Button mode="contained"  onPress={handleRegister}>Login</Button>
      )}
        <Button mode="text" onPress={()=> navigation.navigate("Register")}>Create Account</Button>
        </Card.Content>
      </Card>

      
    </View>
  );
};

export default LoginScreen;
