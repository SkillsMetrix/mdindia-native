import { View, Text } from 'react-native'
import React from 'react'
import { createDrawerNavigator } from '@react-navigation/drawer'
import HomeScreen from '../screens/HomeScreen'
import QuizScreen from '../screens/QuizScreen'
import ResultScreen from '../screens/ResultScreen'
import AboutScreen from '../screens/AboutScreen'
const Drawer= createDrawerNavigator()
const DrawerNavigator = () => {
  return (
   <Drawer.Navigator>
    <Drawer.Screen
    name="Home" component={HomeScreen}/>
     <Drawer.Screen
    name="Quz" component={QuizScreen}/>
     <Drawer.Screen
    name="Results" component={ResultScreen}/>
     <Drawer.Screen
    name="About" component={AboutScreen}/>
   </Drawer.Navigator>
  )
}

export default DrawerNavigator