import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import TabNavigator from '../navigation/TabNavigator'

const HomeScreen = () => {
  return (
     <TabNavigator/>
  )
}

export default HomeScreen

const styles = StyleSheet.create({})