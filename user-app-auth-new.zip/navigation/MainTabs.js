import React from "react";
import { View } from "react-native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";
import DashBoard from "../screens/DashBoard";
import UserDetailsScreen from "../screens/UserDetailsScreen";
import { useAuth } from "../context/AuthContext";

const Tab = createBottomTabNavigator();

// Logout has no screen of its own - pressing the tab just signs the user
// out. This keeps it reachable from every tab without a dedicated route.
const EmptyScreen = () => <View />;

const MainTabs = () => {
  const { logout } = useAuth();

  return (
    <Tab.Navigator>
      <Tab.Screen
        name="Dashboard"
        component={DashBoard}
        options={{
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="home" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Users"
        component={UserDetailsScreen}
        options={{
          title: "User Management",
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="people" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Logout"
        component={EmptyScreen}
        options={{
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="log-out" color={color} size={size} />
          ),
        }}
        listeners={{
          tabPress: (e) => {
            e.preventDefault();
            logout();
          },
        }}
      />
    </Tab.Navigator>
  );
};

export default MainTabs;
