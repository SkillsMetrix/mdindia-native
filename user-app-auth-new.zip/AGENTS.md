# Expo HAS CHANGED

Read the exact versioned docs at https://docs.expo.dev/versions/v57.0.0/ before writing any code.

This project is on Expo SDK 57 (React Native 0.86, React 19.2).
Install dependencies with `npx expo install <pkg>` so versions stay aligned with the SDK,
and validate with `npx expo-doctor` after changing dependencies.
