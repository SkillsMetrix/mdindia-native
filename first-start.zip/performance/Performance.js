import { useCallback, useMemo, useState } from "react";
import useUsers from "./useUsers";

function PerformanceApp() {
  // invoking custom hooks
  const users = useUsers();

  const [search, setSearch] = useState("");
  // useMemo

  const filteredUsers = useMemo(() => {
    console.log("Filtering Users....!");
    return users.filter((user) =>
      user.name.toLowerCase().includes(search.toLowerCase()),
    );
  }, [users, search]);

  // useCallback
  const handleSearch= useCallback((e)=>{
    setSearch(e.target.value)

  },[])
  return (
    <div style={{padding:'20px'}}>
        <h2>User List Data</h2>


        <input type="text" placeholder="Enter User" value={search} onChange={handleSearch}/>
        <ul>
            {filteredUsers.map((user) => (
                      <li key={user.id}>
                        {user.name} --- {user.email}
                      </li>
            ))}
          
        </ul>
    </div>
  )
}

export default PerformanceApp