const { useState, useEffect } = require("react");

// custom hooks
function useUsers(){
    const [users,setUsers]= useState([])


    useEffect(()=>{
        fetch("https://jsonplaceholder.typicode.com/users")
        .then((response) => response.json())
        .then((data) => setUsers(data))
    },[])
    return users
}

export default useUsers;
