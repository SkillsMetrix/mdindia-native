


import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Users = (props) => {
  return (
    <View style={styles.listContainer}>
      {props.us.map((item,index) =>(
        <View key={index} style={styles.listItem}>
            <Text style={styles.bullet}>{"\u2022"}</Text>
              <Text style={styles.text}>{item}</Text>
        </View>
      ))}
    </View>
  )
}

export default Users

const styles = StyleSheet.create({
    listContainer:{
        padding: 20
    },
    listItem:{
        flexDirection: 'row',
        alignItems: 'flex-start',
        marginBottom: 8
    },
    bullet:{
        width: 20,
        fontSize:20,
        lineHeight: 22
    },
    text:{
        flex:1,
        fontSize:16,
        lineHeight: 22
    }
})