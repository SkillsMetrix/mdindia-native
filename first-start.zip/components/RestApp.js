import { StyleSheet, Text, View } from "react-native";
import axios from "axios";
import React, { useEffect, useState } from "react";
import RestData from "./RestData";
const URL = "https://jsonplaceholder.typicode.com/users";
const RestApp = () => {
  // initialize the state
  const [users, setUsers] = useState([]);
  // load the data during loadtime
  useEffect(() => {
    axios
      .get(URL)
      .then((response) => response.data)
      .then((data) => {
        setUsers(data);
      });
  }, []);
  return (
    <View>
      <RestData dt={users} />
    </View>
  );
};

export default RestApp;

const styles = StyleSheet.create({});
