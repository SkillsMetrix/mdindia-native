import { StyleSheet, Text, View, TextInput, Button, Alert } from "react-native";
import React from "react";

const AddUser = () => {
  const addUser2 = () => {
    Alert.alert("user added");
  };

  return (
    <View>
      <Button title="Add User" onPress={addUser2}></Button>
    </View>
  );
};

export default AddUser;

const styles = StyleSheet.create({});
