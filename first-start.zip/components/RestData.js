import { StyleSheet, Text, View } from "react-native";
import React from "react";

const RestData = (props) => {
  return (
    <View>
      {props.dt.map((user) => (
        <Text key={user.name}>{user.name} </Text>
      ))}
    </View>
  );
};

export default RestData;

const styles = StyleSheet.create({});
