import { Text, StyleSheet, View } from 'react-native'
import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <View>
        <Text>{this.props.fd}</Text>
      </View>
    )
  }
}

const styles = StyleSheet.create({})


