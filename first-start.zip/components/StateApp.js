import { StyleSheet, Text, TextInput, View } from 'react-native'
import React, { useEffect, useState } from 'react'

const StateApp = () => {
    //state init
    const [name,setName]= useState('')
    const [email,setEmail]=useState('')

    useEffect(()=>{
        console.log(name);
        console.log(email);
        
        
    },[])


  return (
    <View>
     <TextInput placeholder='Enter Name' value={name} onChangeText={(e)=> setName(e)}/>
             <TextInput placeholder='Enter Email' value={email} onChangeText={(e)=> setEmail(e)}/>

    </View>
  )
}

export default StateApp

const styles = StyleSheet.create({})