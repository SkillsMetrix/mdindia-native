import { Text, StyleSheet, View } from "react-native";
import React, { Component } from "react";

export default function Header(props) {
  return (
    <View>
      <Text>{props.hd}</Text>
    </View>
  );
}

const styles = StyleSheet.create({});
