import { Text, StyleSheet, View } from "react-native";
import React, { Component } from "react";
import Header from "./Header";
import Footer from "./Footer";
import Users from "./Users";
import AddUser from "./AddUser";
import StateApp from "./StateApp";
import RestApp from "./RestApp";

export default function MainApp() {
  let headerData = "Welcome to Header";
  let footerData = "Welcome to Footer";
  let users= ['admin','manager','qa']
  return (
    <View>
      <RestApp/>
      {/* <Header hd={headerData}/>
      <Users us={users}/>
      <AddUser/>
      <StateApp/>
      <Footer fd={footerData}/> */}
    </View>
  );
}

const styles = StyleSheet.create({});
