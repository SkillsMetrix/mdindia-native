import { NavigationContainer } from '@react-navigation/native';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import DrawerNavigator from './navigation/DrawerNavigator';
import { PaperProvider } from 'react-native-paper';
import { theme } from './theme/theme';
import { Provider } from 'react-redux'
import { store } from './app/store';
export default function App() {
  return (
    <Provider store={store}>
    <PaperProvider theme={theme}>
    <NavigationContainer>
      <DrawerNavigator/>
    </NavigationContainer>
    </PaperProvider>
    </Provider>
  );
}
 