
import axios from 'axios'
import Constants from 'expo-constants'
import { Platform } from 'react-native'

const PORT = 3000

const getBaseUrl = () => {
  if (Platform.OS === 'web') {
    return `http://localhost:${PORT}`
  }
  const hostUri = Constants.expoConfig?.hostUri ?? Constants.expoGoConfig?.debuggerHost
  const host = hostUri?.split(':')[0]
  return host ? `http://${host}:${PORT}` : `http://localhost:${PORT}`
}

const BASE_URL = getBaseUrl()

export const getQuestions= async ()=>{
    const response=await axios.get(`${BASE_URL}/questions`)
    return response.data
}