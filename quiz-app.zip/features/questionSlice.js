import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { getQuestions } from "../services/questionAPI";

export const fetchQuestions = createAsyncThunk(
  "questions/fetchQuestions",

  async () => {
    return await getQuestions();
  },
);
const initialState = {
  questions: [],
  loading: false,
  error: null,
};
const questionSlice = createSlice({
  name: "questions",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchQuestions.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchQuestions.fulfilled, (state, action) => {
        state.loading = false;
        state.questions = action.payload;
      })
      .addCase(fetchQuestions.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});
export default questionSlice.reducer;
