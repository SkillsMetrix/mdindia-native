import { createSlice } from "@reduxjs/toolkit";
import { questions } from "./quiz/questions";

const initialState = {
  currentQuestionIndex: 0,
  selectedAnswers: [],
  score: 0,
  skippedQuestions: 0,
  completed: false,
};
const quizSlice = createSlice({
  name: "quiz",
  initialState,
  reducers: {
   answerQuestion: (state, action) => {
  const answer = action.payload;

  state.selectedAnswers.push(answer);

  if (answer.isCorrect) {
    state.score += 1;
  }
},
    nextQuestion: (state) => {
      if (state.currentQuestionIndex < questions.length - 1) {
        state.currentQuestionIndex++;
      } else {
        state.completed = true;
      }
    },
    skippedQuestions: (state) => {
      state.skippedQuestions++;
      if (state.currentQuestionIndex < questions.length - 1) {
        state.currentQuestionIndex++;
      } else {
        state.completed = true;
      }
    },
    calculateScore: (state) => {
      let score = 0;
      state.selectedAnswers.forEach((answer) => {
        const question = questions.find((q) => q.id === answer.questionId);

        if (question && question.answer === answer.selectedOptions) {
          score++;
        }
      });
      state.score = score;
    },
    resetQuiz: () => initialState,
  },
});
export const { answerQuestion, nextQuestion, skippedQuestions, resetQuiz ,calculateScore} =
  quizSlice.actions;
export default quizSlice.reducer;

