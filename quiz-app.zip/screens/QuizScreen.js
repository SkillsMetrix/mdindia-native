import { Alert, View } from 'react-native'
import React, { useEffect, useState } from 'react'
import { StyleSheet } from "react-native";
import { answerQuestion, calculateScore, nextQuestion, skippedQuestions } from '../features/quizSlice'
import { useDispatch, useSelector } from 'react-redux'
import {Button, Card,ProgressBar,RadioButton,Text} from 'react-native-paper'
//import { questions } from '../features/quiz/questions';
import AnswerCard from '../components/AnswerCard';
import { fetchQuestions } from '../features/questionSlice';
const QuizScreen = ({navigation}) => {
  const {currentQuestionIndex}= useSelector(state=> state.quiz)
  const {questions,loading,error}= useSelector(state=> state.questions)
  const dispatch= useDispatch()
  const [selectedOption,setSelectedOption]= useState("")
  const question=questions[currentQuestionIndex]
    useEffect(() =>{
    setSelectedOption("")
  },[currentQuestionIndex])

  useEffect(()=>{
    console.log("quiz mounted");
    
    dispatch(fetchQuestions())
  },[])
  if(loading){
    return (
      <Text>Loading Questions....!</Text>
    )
  }
  if(!questions.length){
    return (
      <Text>No Question....! found</Text>
    )
  }

  const handleNext=() =>{
    if(!selectedOption){
      Alert.alert("Select and Option", "Please select an answer or use skip")
      return
    }
    dispatch(answerQuestion({
    questionId: question.id,
    question: question.question,
    selectedOption,
    correctAnswer: question.answer,
    isCorrect:
      selectedOption === question.answer,
  }))
    if(currentQuestionIndex === questions.length -1){
      dispatch(calculateScore())
      navigation.navigate("Results")
      return
    }
    dispatch(nextQuestion())
  }
  const handleSkip=() =>{
    if(currentQuestionIndex === questions.length -1){
      dispatch(skippedQuestions())
      dispatch(calculateScore())
       navigation.navigate("Result")
      return
    }
    dispatch(skippedQuestions())
  }
  return (
    <View style={styles.container}>

      <Text variant='titleMedium'>Question: {currentQuestionIndex+1} of {questions.length}</Text>
      <ProgressBar progress={(currentQuestionIndex + 1) / questions.length} style={styles.progressBar}/>

      <Card style={styles.card}>
        <Card.Content>
            <Text variant='headlineSmall' style={styles.question}>
              {question.question}
            </Text>


       {question.options.map((option) => (
        <AnswerCard 
        
          key={option}
          option={option}
          selected={selectedOption === option}
          onPress={() => setSelectedOption(option)}
        
        />
       ))}

         
        </Card.Content>
      </Card>
      <Button mode='contained' style={styles.nextButton} onPress={handleNext}>
        {currentQuestionIndex === questions.length -1 ? "Finish Quiz" : "Next"}
      </Button>
      <Button mode='contained' style={styles.skipButton} onPress={handleSkip}>Skip Question</Button>
    </View>
  )
}

export default QuizScreen

const styles= StyleSheet.create({
    container:{
        flex:1,
        padding:15
    },
    progressBar:{
        marginVertical: 15,
        height: 10,
        borderRadius:10
    },
    card: {
        marginTop:10,
        borderRadius: 16
    },
    question:{
        marginBottom:15,
        fontWeight:'bold'
    },
    nextButton: {
        marginTop:20,
        borderRadius:12
    },
       skipButton: {
        marginTop:10,
        borderRadius:12
    }
})


