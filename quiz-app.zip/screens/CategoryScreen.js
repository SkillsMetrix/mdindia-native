import { ScrollView, StyleSheet, View } from 'react-native'
import React from 'react'
import { Card, Text } from 'react-native-paper'


const categories=['React Native','JavaScript','Redux','Expo','GIT']
const CategoryScreen = () => {
  return (
    <ScrollView style={{padding:15}}>
      {categories.map((item,index) => (
        <Card key={index} style={{marginBottom:10}}>
          <Card.Content>
            <Text variant='titleMedium'>
              {item}
            </Text>
          </Card.Content>
        </Card>
      ))}
    </ScrollView>
  )
}

export default CategoryScreen

const styles = StyleSheet.create({})