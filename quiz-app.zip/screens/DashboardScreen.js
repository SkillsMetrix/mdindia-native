import { ScrollView } from 'react-native'
import { StyleSheet, View } from 'react-native'
import {Button, Card,Text} from 'react-native-paper'

const DashboardScreen = ({navigation}) => {
  return (
    <ScrollView style={{padding:15}}>

      <Card style={{marginBotton:15}}>
        <Card.Content>
          <Text variant='headlineSmall'>
            MDIndia Quiz Master
          </Text>
          <Text variant='bodyMedium'>
            Test Your Technical Skills
          </Text>
        </Card.Content>
      </Card>

    
      <Card style={{marginTop:15}}>
        <Card.Content>
          <Text >
           Total Questions: 20
          </Text>
          <Text >
            Difficulty: Medium
          </Text>
           <Text >
           Passing Score: 70%
          </Text>
        </Card.Content>
      </Card>
      <Button mode='contained' onPress={()=> navigation.navigate("Quiz")}>Start Quiz</Button>
    </ScrollView>
     
  )
}

export default DashboardScreen

const styles = StyleSheet.create({})