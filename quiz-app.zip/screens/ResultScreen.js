import { StyleSheet,  View } from 'react-native'
import { useDispatch, useSelector } from 'react-redux'
import React from 'react'
import {Button, Card,Chip,Text,Divider} from 'react-native-paper'
import { questions } from '../features/quiz/questions'
import { resetQuiz } from '../features/quizSlice'
import { ScrollView } from 'react-native'


export default function ResultScreen({ navigation }) {
  const dispatch = useDispatch();

  const {
    selectedAnswers,
    skippedQuestions,
  } = useSelector((state) => state.quiz);

  const totalQuestions = questions.length;

  const correctAnswers = selectedAnswers.filter(
    (answer) => answer.isCorrect
  ).length;

  const wrongAnswers = selectedAnswers.filter(
    (answer) => !answer.isCorrect
  ).length;

  const percentage = Math.round(
    (correctAnswers / totalQuestions) * 100
  );

  let badge = "Learner";
  let message = "Keep Practicing";

  if (percentage >= 90) {
    badge = "Quiz Champion";
    message = "Outstanding Performance!";
  } else if (percentage >= 80) {
    badge = "Expert";
    message = "Excellent Work!";
  } else if (percentage >= 70) {
    badge = "Skilled";
    message = "Good Job!";
  }

  const handleRestart = () => {
    dispatch(resetQuiz());
    navigation.navigate("Quiz");
  };

  return (
    <ScrollView style={styles.container}>
      {/* Header Card */}
      <Card style={styles.heroCard}>
        <Card.Content>
          <Text
            variant="headlineMedium"
            style={styles.center}
          >
            🎉 Quiz Completed
          </Text>

          <Text
            variant="displayMedium"
            style={styles.score}
          >
            {percentage}%
          </Text>

          <Chip
            icon="trophy"
            style={styles.badge}
          >
            {badge}
          </Chip>

          <Text style={styles.center}>
            {message}
          </Text>
        </Card.Content>
      </Card>

      {/* Stats */}
      <View style={styles.row}>
        <Card style={styles.statCard}>
          <Card.Content>
            <Text
              variant="headlineSmall"
              style={styles.center}
            >
              {correctAnswers}
            </Text>
            <Text style={styles.center}>
              Correct
            </Text>
          </Card.Content>
        </Card>

        <Card style={styles.statCard}>
          <Card.Content>
            <Text
              variant="headlineSmall"
              style={styles.center}
            >
              {wrongAnswers}
            </Text>
            <Text style={styles.center}>
              Wrong
            </Text>
          </Card.Content>
        </Card>
      </View>

      <View style={styles.row}>
        <Card style={styles.statCard}>
          <Card.Content>
            <Text
              variant="headlineSmall"
              style={styles.center}
            >
              {skippedQuestions}
            </Text>
            <Text style={styles.center}>
              Skipped
            </Text>
          </Card.Content>
        </Card>

        <Card style={styles.statCard}>
          <Card.Content>
            <Text
              variant="headlineSmall"
              style={styles.center}
            >
              {totalQuestions}
            </Text>
            <Text style={styles.center}>
              Total
            </Text>
          </Card.Content>
        </Card>
      </View>

      {/* Summary */}
      <Card style={styles.summaryCard}>
        <Card.Content>
          <Text variant="titleLarge">
            Performance Summary
          </Text>

          <Divider
            style={{ marginVertical: 10 }}
          />

          <Text>
            Accuracy: {percentage}%
          </Text>

          <Text>
            Attempted: {selectedAnswers.length}
          </Text>

          <Text>
            Skipped: {skippedQuestions}
          </Text>
        </Card.Content>
      </Card>

      {/* Review */}
      <Text
        variant="headlineSmall"
        style={styles.reviewTitle}
      >
        Review Answers
      </Text>

      {selectedAnswers.map(
        (answer, index) => (
          <Card
            key={index}
            style={styles.reviewCard}
          >
            <Card.Content>
              <Text
                variant="titleMedium"
                style={{
                  marginBottom: 8,
                }}
              >
                {answer.question}
              </Text>

              <Text>
                Your Answer:{" "}
                {answer.selectedOption}
              </Text>

              <Text>
                Correct Answer:{" "}
                {answer.correctAnswer}
              </Text>

              <Text
                style={{
                  marginTop: 8,
                  color: answer.isCorrect
                    ? "green"
                    : "red",
                }}
              >
                {answer.isCorrect
                  ? "✓ Correct"
                  : "✗ Incorrect"}
              </Text>
            </Card.Content>
          </Card>
        )
      )}

      <Button
        mode="contained"
        icon="restart"
        style={styles.restartButton}
        onPress={handleRestart}
      >
        Restart Quiz
      </Button>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
  },

  heroCard: {
    borderRadius: 20,
    marginBottom: 15,
  },

  center: {
    textAlign: "center",
  },

  score: {
    textAlign: "center",
    fontWeight: "bold",
    marginVertical: 15,
  },

  badge: {
    alignSelf: "center",
    marginBottom: 10,
  },

  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },

  statCard: {
    width: "48%",
    borderRadius: 15,
  },

  summaryCard: {
    borderRadius: 15,
    marginVertical: 10,
  },

  reviewTitle: {
    marginTop: 15,
    marginBottom: 10,
  },

  reviewCard: {
    marginBottom: 10,
    borderRadius: 15,
  },

  restartButton: {
    marginVertical: 25,
    borderRadius: 15,
  },
});


