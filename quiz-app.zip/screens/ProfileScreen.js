import { StyleSheet, View } from 'react-native'
import React from 'react'
import { Avatar, Card, Text } from 'react-native-paper'
const ProfileScreen = () => {
  return (
    <View style={{padding:15}}>
      <Card>
        <Card.Content>
          <Avatar.Text size={70} label='AJ' />
          <Text variant='headlineSmall'>
            Amarjeet
          </Text>
           <Text>
            Quizzes Attempted: 4
          </Text>
           <Text>
            Highest Score: 90%
          </Text>
        </Card.Content>
      </Card>
    </View>
  )
}

export default ProfileScreen

const styles = StyleSheet.create({})