

import { StyleSheet, TouchableOpacity, View } from 'react-native'
import React from 'react'
import {Card,Text} from 'react-native-paper'
const AnswerCard = ({option,selected,onPress}) => {
  return (
   <TouchableOpacity onPress={onPress}>
    <Card style={[styles.card,selected && styles.selectedCard]}>
        <Card.Content>
            <Text variant='titleMedium'>
                {option}
            </Text>
        </Card.Content>
    </Card>
   </TouchableOpacity>
  )
}

export default AnswerCard

const styles = StyleSheet.create({
    card: {
        marginVertical: 8,
        borderRadius:15
    },
    selectedCard:{
        borderWidth:2,
        borderColor: '#6200ee'
    }
})