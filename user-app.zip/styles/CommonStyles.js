import { StyleSheet } from "react-native";


export const CommonStyles= StyleSheet.create({
    container: {
    flex: 1,
    padding: 20,
    justifyContent: "center",
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 25,
  },
  input: {
    borderWidth: 1,
    borderColor: "#f84a4a",
    borderRadius: 8,

    padding: 12,
    marginBottom: 15,
  },
  button: {
    backgroundColor: "blue",
    padding: 15,
    borderRadius: 8,
  },
  buttonText: {
    color: "black",
    textAlign: "center",
    fontWeight: "bold",
    fontSize: 16,
  }
})