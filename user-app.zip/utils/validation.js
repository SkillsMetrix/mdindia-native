export const validateRegistration = (formData) => {
  const { username, email, password, confirmPassword } = formData;

  if (!username.trim()) {
    return "Username is required";
  }
  if (!email.trim()) {
    return "Email is required";
  }
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!emailRegex.test(email)) {
    return "Email is invalid";
  }
  return null;
};

export const validateLogin = (formData) => {
  const { username, password } = formData;

  if (!username.trim()) {
    return "Username is required";
  }
  if (!password.trim()) {
    return "Password is required";
  }
 
  return null;
};
