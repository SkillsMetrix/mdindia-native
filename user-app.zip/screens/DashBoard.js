import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const DashBoard = ({route,navigation}) => {
  const user= route.params?.user
  navigation.navigate("UserDetails",{loggedInUser:user[0]})
  return (
    <View>
      <Text>Welcome {user?.username}</Text>

    </View>
  )
}

export default DashBoard

const styles = StyleSheet.create({})