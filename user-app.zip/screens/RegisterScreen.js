import {
  Alert,
  Button,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import React, { useState } from "react";
import { validateRegistration } from "../utils/validation";
import { CommonStyles } from "../styles/CommonStyles";
import { registerUser } from "../services/authService";

const RegisterScreen = ({navigation}) => {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleRegister = async() => {
    const error = validateRegistration(formData);
    if (error) {
      alert("Validation Error", error);
      return;
    }
    try{
      const payload= {username: formData.username,email:formData.email,password:formData.password}
      const user= await registerUser(payload)
      console.log(user);
      navigation.navigate("Login")

    }catch(error){console.log(error);
      alert('registration failed')
    }
    
   
  };

  return (
    <View style={CommonStyles.container}>
      <Text style={CommonStyles.title}>Create Account</Text>
      <TextInput
        placeholder="Enter UserName"
        style={CommonStyles.input}
        value={formData.username}
        onChangeText={(value) => handleChange("username", value)}
      />

      <TextInput
        placeholder="Enter Email"
        style={CommonStyles.input}
        value={formData.email}
        onChangeText={(value) => handleChange("email", value)}
      />

      <TextInput
        placeholder="Enter Password"
        style={CommonStyles.input}
        secureTextEntry
        value={formData.password}
        onChangeText={(value) => handleChange("password", value)}
      />

      <TextInput
        placeholder="Enter Confirm Password"
        style={CommonStyles.input}
        secureTextEntry
        value={formData.confirmPassword}
        onChangeText={(value) => handleChange("confirmPassword", value)}
      />
      <TouchableOpacity style={CommonStyles.button} onPress={handleRegister}>
        <Text style={CommonStyles.buttonText}>Register</Text>
      </TouchableOpacity>
    </View>
  );
};

export default RegisterScreen;
