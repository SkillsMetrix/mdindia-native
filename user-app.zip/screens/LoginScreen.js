import {
  Alert,
  Button,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import React, { useState } from "react";
import { validateLogin } from "../utils/validation";
import { CommonStyles } from "../styles/CommonStyles";
import { loginUser, registerUser } from "../services/authService";

const LoginScreen = ({ navigation }) => {
  const [formData, setFormData] = useState({
    username: "",
  });
  const handleChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleRegister = async () => {
    const error = validateLogin(formData);
    if (error) {
      alert("Validation Error", error);
      return;
    }
    try {
      const user = await loginUser(formData.username, formData.password);
      if (user.length === 0) {
        alert("Login failed");
        return;
      }
      alert("Login Success");
      navigation.navigate("Dashboard",{
        user:user[0]
      });
    } catch (error) {
      console.log(error);
      alert("unable to login");
    }
  };

  return (
    <View style={CommonStyles.container}>
      <Text style={CommonStyles.title}>Create Account</Text>
      <TextInput
        placeholder="Enter UserName"
        style={CommonStyles.input}
        value={formData.username}
        onChangeText={(value) => handleChange("username", value)}
      />

      <TextInput
        placeholder="Enter Password"
        style={CommonStyles.input}
        secureTextEntry
        value={formData.password}
        onChangeText={(value) => handleChange("password", value)}
      />

      <TouchableOpacity style={CommonStyles.button} onPress={handleRegister}>
        <Text style={CommonStyles.buttonText}>Login</Text>
      </TouchableOpacity>
    </View>
  );
};

export default LoginScreen;
