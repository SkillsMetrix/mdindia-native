import { StyleSheet, Text, View } from "react-native";
import React, { useEffect, useState } from "react";
import { loadUsers } from "../services/authService";

const UserDetailsScreen = ({ navigation }) => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  const loadUsers = async () => {
    try {
      const data = await loadUsers();
      console.log(data);

      setUsers(data);
    } catch (error) {
      console.log("Unable to load Users");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
     
  }, []);

  return (
    <View>
      <Text>UserDetailsScreen</Text>
    </View>
  );
};

export default UserDetailsScreen;

const styles = StyleSheet.create({});
