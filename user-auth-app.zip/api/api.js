import axios from 'axios'
import Constants from 'expo-constants'
import { Platform } from 'react-native'
import AsyncStorage from '@react-native-async-storage/async-storage'

const BACKEND_PORT = 3000

// On web, the backend runs on the same machine, so localhost works.
// On a device/emulator (Expo Go or a dev build), "localhost" refers to the
// device itself, not your computer - so we derive the dev machine's LAN IP
// from the Metro/Expo debugger host instead.
const getBaseUrl = () => {
  if (Platform.OS === 'web') {
    return `http://localhost:${BACKEND_PORT}`
  }

  const hostUri =
    Constants.expoConfig?.hostUri ?? Constants.expoGoConfig?.debuggerHost

  const host = hostUri?.split(':')[0]

  if (!host) {
    console.warn(
      'Could not detect dev machine IP from Expo host info; falling back to localhost. ' +
        'If requests fail on a device/emulator, set your machine\'s LAN IP manually in api/api.js.'
    )
    return `http://localhost:${BACKEND_PORT}`
  }

  // Android emulator (not a physical device) maps the host machine to 10.0.2.2
  if (Platform.OS === 'android' && host === 'localhost') {
    return `http://10.0.2.2:${BACKEND_PORT}`
  }

  return `http://${host}:${BACKEND_PORT}`
}

const api = axios.create({
  baseURL: getBaseUrl(),
})

// Attach the stored JWT to every request, so screens/services never have to.
api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

export default api
