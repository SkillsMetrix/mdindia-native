import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';

export default function DetailsPage() {
  // Read params and cast string types cleanly to clear out routing constraint conflicts
  const params = useLocalSearchParams();
  const userId = (params.userId as string) ?? 'N/A';
  const fallbackName = params.fallbackName as string | undefined;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Details Screen</Text>
      
      <View style={styles.infoBox}>
        <Text style={styles.label}>Passed Route User ID:</Text>
        <Text style={styles.value}>{userId}</Text>

        <Text style={styles.label}>Passed Fallback Name:</Text>
        <Text style={styles.value}>{fallbackName ?? "No name parameter sent."}</Text>
      </View>

      <Button title="← Return to Hub" color="#64748b" onPress={() => router.back()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, backgroundColor: '#ffffff', justifyContent: 'center' },
  title: { fontSize: 28, fontWeight: 'bold', color: '#0f172a', marginBottom: 20 },
  infoBox: { backgroundColor: '#f1f5f9', padding: 16, borderRadius: 8, marginBottom: 24 },
  label: { fontSize: 11, fontWeight: '700', color: '#64748b', textTransform: 'uppercase' },
  value: { fontSize: 16, color: '#1e293b', marginBottom: 12, marginTop: 2 },
});