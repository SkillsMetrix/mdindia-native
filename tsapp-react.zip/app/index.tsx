import React from "react";
import { StyleSheet, Text, View, Button } from "react-native";
import { router } from "expo-router";

// ==========================================
// 1. API Response Types & Nullable Handling
// ==========================================
export interface UserProfile {
  id: string;
  name: string;
  email: string;
  bio: string | null;          // Explicitly can be null from backend
  phoneNumber?: string;        // Optional property (undefined)
  avatarUrl?: string | null;   // Can be optional AND null
}

export interface ApiResponse<T> {
  data: T;
  status: number;
  message: string;
}

// ==========================================
// 2. Utility Types (Partial, Pick)
// ==========================================
export type UpdateProfilePayload = Partial<UserProfile>; // Everything optional
export type UserPreview = Pick<UserProfile, 'name' | 'avatarUrl'>; // Only name and avatar

// Inline component validating utility types as props
function UserCard({ user }: { user: UserPreview }) {
  return (
    <View style={styles.card}>
      <Text style={styles.cardText}>Name: {user.name}</Text>
      <Text style={styles.cardSubtext}>
        {user.avatarUrl ? "Custom Avatar Active" : "No Avatar Attached"}
      </Text>
    </View>
  );
}

// ==========================================
// 3. Screen Component Layout
// ==========================================
export default function Page() {
  // Mock API response showcasing strict type parameters
  const mockUser: UserProfile = {
    id: "usr_78945",
    name: "Stark Tech",
    email: "stark@domain.com",
    bio: null,               // Nullable property demonstration
    phoneNumber: undefined,  // Optional property demonstration
  };

  // Safe filtering via the Pick utility type
  const previewData: UserPreview = {
    name: mockUser.name,
    avatarUrl: mockUser.avatarUrl,
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Type-Safe Hub</Text>
      <Text style={styles.subtitle}>Expo Router Workspace</Text>

      {/* Nullish coalescing (??) fallback for Nullable and Optional types */}
      <Text style={styles.debugText}>
  Bio Value: {mockUser.bio || "Property is empty or null."}
</Text>

<Text style={styles.debugText}>
  Phone Value: {mockUser.phoneNumber || "Property is empty or undefined."}
</Text>

      {/* Render with strict utility props */}
      <UserCard user={previewData} />

      {/* 4. Simpler Route Param Navigation String Passing */}
      <Button 
        title="Go to Details Screen" 
        color="#3b82f6"
        onPress={() => {
          router.push({
            pathname: "/details",
            params: { userId: mockUser.id, fallbackName: mockUser.name }
          });
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 24, backgroundColor: "#ffffff", justifyContent: "center" },
  title: { fontSize: 32, fontWeight: "bold", color: "#0f172a" },
  subtitle: { fontSize: 16, color: "#64748b", marginBottom: 20 },
  debugText: { fontSize: 13, color: "#b91c1c", backgroundColor: "#fef2f2", padding: 8, borderRadius: 6, marginVertical: 4 },
  card: { padding: 16, backgroundColor: "#f8fafc", borderRadius: 8, borderWidth: 1, borderColor: "#e2e8f0", marginVertical: 14 },
  cardText: { fontSize: 15, fontWeight: "600", color: "#334155" },
  cardSubtext: { fontSize: 12, color: "#94a3b8", marginTop: 2 }
});